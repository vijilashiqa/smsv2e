import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-headendview',
  templateUrl: './headendview.component.html',
  styleUrls: ['./headendview.component.scss']
})
export class HeadendviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
