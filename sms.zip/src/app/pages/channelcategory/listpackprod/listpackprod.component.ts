import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-listpackprod',
  templateUrl: './listpackprod.component.html',
  styleUrls: ['./listpackprod.component.scss']
})
export class ListpackprodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  Addmake(){
    
  }

}
