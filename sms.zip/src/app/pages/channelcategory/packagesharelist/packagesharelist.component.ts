import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'ngx-packagesharelist',
  templateUrl: './packagesharelist.component.html',
  styleUrls: ['./packagesharelist.component.scss']
})
export class PackagesharelistComponent implements OnInit {
  
  constructor(
    
  ) { }

  ngOnInit(): void {
  }
  
}
